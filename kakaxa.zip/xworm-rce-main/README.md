**dont open issues if the rce isnt working this is old af and rce is patched on new xworms**

# xworm-rce
execution of Powershell scripts and files on a XWorm C2.
aka remote code execution on xworm
theres also a scraper to scrape xworm c2s on ts

please **use this responsibly** and only test it on urself. this is made for people wondering how xworm works or are just curious to try stuff out

do NOT use this for malicious purposes, only test this on VIRTUAL MACHINES, not your main pc

do not use this on real targets
use educationaly only

and plz credit if you skid this

# information

usage: python rce.py -H host -p port -k (option defaults to the default xworm key

where to find c2s: solara discord, malwarebazaar, anyrun, ratting servers (some 'cracked rats' are backdoored), github (search for cracked rats)

github cleared stars for some reason after i unprivated 💔
